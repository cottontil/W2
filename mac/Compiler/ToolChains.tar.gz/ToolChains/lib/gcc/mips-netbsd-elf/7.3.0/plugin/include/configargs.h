/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-src/configure --target=mips-netbsd-elf --prefix=/Users/daizhirui/mips-cross-compiler --disable-nls --enable-languages=c,c++ --without-headers --with-gnu-as --with-gnu-ld --disable-multilib --disable-shared --disable-decimal-float --disable-threads --disable-libmudflap --disable-libssp --disable-libgomp";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
