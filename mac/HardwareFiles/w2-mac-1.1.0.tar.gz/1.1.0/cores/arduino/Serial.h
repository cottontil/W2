void SetBaudRate(unsigned long buadRate);

void Putch(char ch);
void Puts(char const* str);

char* itoa(int num, char* str, int radix);
int atoi(const char* str);

char ReadChar();